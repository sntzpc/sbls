// app.js — bootstrap aplikasi
import { initUI } from './ui.js';

window.addEventListener('DOMContentLoaded', ()=>{
  initUI();
});
